download.file("https://raw.githubusercontent.com/pandoc/lua-filters/master/scholarly-metadata/scholarly-metadata.lua","Filters/scholarly-metadata.lua", method = "libcurl")
download.file("https://raw.githubusercontent.com/pandoc/lua-filters/master/author-info-blocks/author-info-blocks.lua","Filters/author-info-blocks.lua", method = "libcurl")
download.file("https://gist.githubusercontent.com/DanChaltiel/e7505e62341093cfdc489265963b6c8f/raw/174124305d5720682b1779e8c3731c1b2ffef0d1/pagebreaks.lua","Filters/pagebreaks.lua", method = "libcurl")
